//
//#include<iostream>
//#include"Employee.h"
//#include "date.h"
//
//using namespace std;
//Employee::Employee(){}
//Employee::Employee(int empid, const char* nm, int dd, int mm, int yy)
//{
//	this->empid = empid;
//	name = CString(nm);
//	doj = Date(dd, mm, yy);
//}
//void Employee::accept()
//{
//	cout << "Enter empid" << endl;
//	cin >> empid;
//	cin >> name;
//	cin >> doj;
//}
//void Employee::show()
//{
//	cout << "Employee details are:";
//	cout << empid << " " << name << " " << doj << endl;;
//}
//
