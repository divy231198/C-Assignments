#include <iostream>
#include "Wage.h"

using namespace std;
WageEmployee::WageEmployee()
{
}

WageEmployee::WageEmployee(int id, const char* nm, int dd, int mm, int yy, float hr , float rate):Employee(id, nm, dd,mm,yy),hrs(hr),rate(rate)
{
}

void WageEmployee::accept()
{
	Employee::accept();
	cout << "Enter hrs and rate" << endl;
	cin >> hrs >> rate;
}

void WageEmployee::show()
{
	Employee::show();
	cout << " hrs and rate" << endl;
	cout << hrs << " "<<rate << endl;
}

float WageEmployee::computesal()
{
	return hrs*rate;
}
